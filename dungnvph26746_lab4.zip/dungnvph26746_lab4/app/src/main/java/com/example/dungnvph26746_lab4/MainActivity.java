package com.example.dungnvph26746_lab4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btn_b1,btn_b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_b1=findViewById(R.id.btn_b1);
        btn_b2=findViewById(R.id.btn_b2);
        btn_b1.setOnClickListener(view -> {
            Intent intent = new Intent(getBaseContext(),Bai1Activity.class);
            startActivity(intent);
        });
        btn_b2.setOnClickListener(view -> {
            Intent intent = new Intent(getBaseContext(),Bai2Activity.class);
            startActivity(intent);
        });

    }
}