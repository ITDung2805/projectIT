package com.example.dungnvph26746_lab4;

import androidx.appcompat.app.AppCompatActivity;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.Toast;

public class Bai2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);

        ConnectivityManager manager= (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo checkwifi= manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo check4g= manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

        if (checkwifi.isConnected()) Toast.makeText(this, "Use Wifi", Toast.LENGTH_LONG).show();
        if (check4g.isConnected()) Toast.makeText(this, "Use 4G", Toast.LENGTH_LONG).show();

    }
}